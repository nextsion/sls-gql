# Getting Started

You can now develop all of your AppSync API's locally using Serverless + Serverless-AppSync-Plugin! With support for AWS DynamoDB, AWS Lambda, and AWS Elasticsearch; you have everything you need to get started developing your AppSync API's locally.

## 🛠 Minimum requirements

Node.js v8 or higher
Serverless v1.30.0 or higher

Once installed the Serverless CLI can be called with serverless or the shorthand sls command.

```

sls
```

Commands
* You can run commands with "serverless" or the shortcut "sls"
* Pass "--verbose" to this command to get in-depth plugin info
* Pass "--no-color" to disable CLI colors
* Pass "--help" after any <command> for contextual help

## 💾 Installation

Install the plugin via Yarn (recommended)

```

yarn add serverless-appsync-plugin
```

or via NPM

```

npm install serverless-appsync-plugin
```

## 📝Offline support

The serverless-offline plugin emulates AWS λ and API Gateway on your local machine to speed up your development cycles. To do so, it starts an HTTP server that handles the request's lifecycle like APIG does and invokes your handlers.

Features:

Node.js, Python and Ruby λ runtimes.
Velocity templates support.
Lazy loading of your files with require cache invalidation: no need for a reloading tool like Nodemon.
And more: integrations, authorizers, proxies, timeouts, responseParameters, HTTPS, CORS, etc...


Install the plugin

```

npm install --save serverless-offline
```

Start local enviroment:
In your project root run:

`serverless offline` or `sls offline`.

to list all the options for the plugin run:

`sls offline --help`

By default you can send your requests to `http://localhost:3000/`.

## 🚀 Serverless deploy

This command will deploy all AppSync resources in the same CloudFormation template used by the other serverless resources.

`sls deploy`

## ✏️ Invoke deployed function

Invoke deployed function with command invoke and --function or shorthand -f.

`sls invoke -f graphql`

In your terminal window you should see the response from AWS Lambda.

```

{
    "statusCode": 200,
    "body": "{\"message\":\"Go Serverless v1.0! Your function executed successfully!\",\"input\":{}}"
}
```
